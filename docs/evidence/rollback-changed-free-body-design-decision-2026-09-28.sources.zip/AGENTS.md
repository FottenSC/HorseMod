# HorseMod project instructions

## Read first

- Active plan and acceptance criteria: [docs/rollback-depth-seven-plan.md](docs/rollback-depth-seven-plan.md).
- Current implementation, evidence and next experiment: [docs/rollback-status.md](docs/rollback-status.md).
- Historical notes: [docs/history/depth-seven-reset-2026-09-14](docs/history/depth-seven-reset-2026-09-14). These are archived evidence, not current instructions.
- Keep AGENTS.md for durable working rules only. Never prepend run results, binary hashes, progress checkpoints or next-step status here. Update the standalone status file at coherent checkpoints; link retained evidence instead of duplicating campaigns.

## Scope and collaboration

- Finish local rolling rollback at depth seven within active combat in one retained match. Follow the ordered plan. Historical replay seeking and networking are deferred.
- Preserve verified implementation, unrelated dirty work and primary evidence. Use the existing checkout and build directory; do not restart the rewrite or create redundant project copies.
- Investigate native consumers and ownership before changing affected behavior. Treat annotations as evidence to verify, not specifications. Limit reverse engineering to dependencies that block the assembled test.
- Ground claims in source, native code and retained observations. State what is implemented, locally tested, demonstrated live and still unproven separately.
- Continue through routine edits, builds and helper passes. Stop a failing experiment at its first failure, investigate, and retry only after a specific fix, instrumentation change or falsifiable hypothesis.
- Do not make external reviewer availability a prerequisite. Recheck disagreements against primary evidence.

## Ownership and correctness

- Preserve complete B undo until corrected execution and required application/render completion succeed. Keep existing lifetime, membership, GPU completion and deferred-retirement guards.
- Submission is not GPU completion; timeout is not cancellation. Never free in-flight resources or resume partially restored state.
- Logical creation/destruction, callbacks, scheduling, RNG, physics, animation and particle lifecycle must remain correct. No PendingKill revival, required-callback suppression or logically dead owners kept active.
- Expected observations are comparison data only; never import them to manufacture deterministic agreement.
- Exact historical pixels are optional. Coherent actors/effects/poses/HUD and all simulation feedback remain required. A held image proves paused display only.
- Production owned-memory ceiling is 1 GiB; up to 2 GiB is permitted for bounded diagnostics. Account for simultaneous checkpoint, complete-B, operation, scratch, native/GPU, in-flight and deferred ownership. Extra memory is permission, not a target.

## Build and tests

- Reuse `python tools/replay_test.py <stage>` and `build_cmake_LessEqual421__Shipping__Win64`. Extend existing tools narrowly; do not create another harness.
- During tooling edits, use affected `local --test` selections or `--changed-path` groups; use `--layer unit|workflow|native-contract` when the change is confined to that layer. Run broad checks at coherent checkpoints and preserve the full-suite requirement for live admission. See [the tooling guide](docs/rollback-tooling.md); selected or filtered passes never qualify G3.
- For locally reproducible defects, first add a production-boundary regression that fails before the fix. Use live tests only for native behavior local tests cannot establish. Avoid fixtures that grant the behavior under test.
- Use the shortest representative combat segment. Prefer existing evidence and compatible independent controls. Do not repeat full playback or qualification campaigns to debug one failure.
- Verify native signatures and exact game/runtime/framework/observer/replay identities before deployment. Match setup interventions, including intro skipping, in candidate and independent control.
- Run tests and cleanup yourself. Use the deployment/recovery journal, verify the mapped DLLs, restore prior files/configuration, terminate only owned test processes, and leave existing Steam clients running.
- Keep bounded raw logs and reconstructible source contents, including untracked production/test files. Reports must link their retained logs, not overwritten working paths. Be mindful of disk space.
- Report observer validity, simulation, coherence, recovery and performance separately. An individual experiment pass does not complete its gate. Normal rendering is required for qualification; viewport cadence is not displayed FPS, and resumed TPS is not rollback-update cost.
- Do not use UObject::IsReal in per-tick observation loops: its implementation scans the object array. Use validated indexed lookup.
- Do not add competing hooks at already owned native entries, including 1403FCA60 and 141D38300. Inspect current ownership before installing hooks.

## Repository and native evidence

- `HorseMod/`: C++ mod and deterministic core. `RE-UE4SS/`: engine integration. `tools/`: existing runner and local fixtures. `dump/`: native/asset evidence.
- Additional dumps: `C:/Users/prest/Documents/SoulcaliburModding/SCVI Sound Tools/dump`; copy only files actually needed into the repository.
- Reusable native knowledge: `E:/DevShitPosts/SC6Mods/SC6ModdingDocs`; follow that repository's instructions when editing it.
- `tools/BlueprintToCpp` produces pseudocode from cooked assets, not buildable mod code. Validate against Kismet bytecode/CFG or native traces.
- Lux uses X/Z ground and Y vertical; UE(X,Y,Z) = Lux(X,Z,Y) * 100.

## Ghidra

- Use the existing Soulcalibur program through native Ghidra MCP tools. Never import a second copy, edit .gpr files directly, or use scripts for database edits. Avoid currently unreliable snapshot endpoints.
- Sole existing exporter exception: `ghidraCalibur/tools/refresh_ghidra_calibur.ps1`, after MCP save_program, may run checked-in StructuredExporter.java read-only through MCP. It must reject concurrent modifications and never modify the database.
- Use the applicable function/type skill when documenting or recovering types. Improve directly relevant names/types/comments while investigating; do not expand into unrelated annotation work.
- Function names: PascalCase verbs; globals: g_ plus typed prefix; labels: snake_case. Pass logical field names where MCP automatically supplies prefixes. Resolve undefined types before Hungarian variable names; use Ghidra builtins for local types.
- Structural/prototype changes precede comments because set_function_prototype wipes plate comments. Apply comments through native comment tools with actual newlines; bookmarks are not substitutes. Verify the result.
- For register-only or decompiler-artifact variables that cannot be typed, document the limitation instead of repeatedly forcing edits. Tool-exposure failures must be reported honestly, not represented as completed annotations.
