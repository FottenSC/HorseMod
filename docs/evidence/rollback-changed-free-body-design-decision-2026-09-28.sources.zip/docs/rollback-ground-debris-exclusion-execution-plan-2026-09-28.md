# Depth-seven rollback with ground-debris motion excluded from exact simulation state

## Decision to evaluate

For the admitted active-combat A617→C624 window, treat **numeric ground-debris child pose and velocity as presentation state** if their motion has no path into future combat or required shared callbacks. This is a scoped working assumption, not a claim that all PhysX or all debris is cosmetic. Logical debris birth/death, slot and group membership, pending impulses, RNG draws, callbacks, scheduler obligations, collision ownership and application/render work remain authoritative unless their own consumers are independently closed. A failed admission condition rejects the transaction.

The [active local-readiness plan](rollback-netcode-local-readiness-plan-2026-09-22.md) and [depth-seven acceptance contract](rollback-depth-seven-plan.md) govern ordering and acceptance. This document makes one implementation route concrete. Do not use an older handover's next step. Read [rollback-status.md](rollback-status.md) only for current checkout, test and deployment state, then update it at coherent checkpoints.

## 0. Recover and record the baseline

1. Verify the existing checkout, dirty and untracked source, build directory, game/runtime/framework/observer/replay hashes, receipt compatibility, deployment journal and independent game/Steam process inventory. Preserve current work and source archives. Do not create another checkout or harness.
2. Confirm the selected A617→C624 window's native tick/epoch and actual effect lifecycle. Keep the existing early particle and GPU lifetime evidence as separate regressions; do not silently select an event-free window.
3. Run only the selected local checks needed to characterize current failures. The changed-free-body `test_physics_dispatch_rejects_free_body_changed_after_entry` is presently RED (fixture exit 136); a prior passing build and volume-flag regression do not certify G0. Stop at the first failure and retain its immutable receipt.

**Exit:** a source-qualified baseline, clean/recoverable deployment state, exact active blocker list, and no unsupported claim that A617 was observed on current source.

## 1. Turn the debris assumption into a bounded state policy

Use the [outgoing-consumer audit](evidence/rollback-debris-motion-consumers-2026-09-28.md) as evidence to recheck in the existing `SoulcaliburVI.exe` Ghidra program. The dispatcher `142028750` reads body pose, writes the child's Unreal transform through `141DA43E0`/`141DA2820`, and reaches transform fan-out `141DA79D0`. It is not a render-only dispatcher.

1. Define the exact admitted owner set: ground-ring roots and children, their WorldSettings actor, body/shape bindings, native scene, task family, combat epoch and window. Reject unknown types, owner changes or replacement identities.
2. At the **actual consumption boundary**, verify the immediate fan-out predicates: PhysicsOnly collision and current filter result; empty overlaps; no attached children or scoped movement; no transform callback entries; physics-volume update flag `component+0x48 & 0x40` clear; inert navigation route; WorldSettings null-root/bounds condition; and expected vtable entries. Recheck after any corrected birth or state transition, not only at A capture.
3. Resolve the two stored-transform readers for this admitted owner: reflected `GetGroundDebris` (`140CF1310`) and Niagara static-mesh source selection (`141BC7F90`). Trace the active registration/binding and selected actor/component, including Blueprint bytecode or live binding where static native xrefs cannot decide reachability. Exact-name package scans alone are insufficient. If a reader reaches combat/shared state, keep its inputs authoritative or reject this policy.
4. Record an explicit state-policy version and comparison rule: combat state/outcomes and required shared effects compare exactly; debris numeric motion may differ; logical existence, callbacks and render coherence still compare. Negative local fixtures must show that a newly enabled callback, volume flag, collision route, reader or wrong owner causes rejection.
5. Once G0 allows deployment, run one shortest ordinary-forward A617 observation to verify the actual flags and active reader topology. A narrowly isolated motion perturbation against an independent **modified** control is a cross-check after structural closure, not a replacement for it. Stop at its first mismatch and trace the first divergent consumer.

**Exit:** an enforced, source-qualified `debris_motion` exclusion for the admitted case, or a named feedback edge that moves the affected state back into the exact set. No universal no-feedback claim is required.

## 2. Resolve the task and complete-B safety prerequisite

The current production-boundary RED shows an unrelated kinematic body can become free after entry admission yet reach the owned PhysX start wrapper. Ghidra shows the popped tick task is bound at tick-function `+0x18`, retained in graph/sequencer references, and its destructor releases a reference without completing the graph event. Holding, dropping or falsely completing that task is not B recovery.

1. Inspect only this start/substep task family's producer, binding, event owner and completion/rejection paths. Determine whether the supported transaction can structurally exclude the mid-update change, or whether it needs a legitimate abort-to-quiescence operation that discharges all native obligations without executing rejected physics. Include resume, not just first dispatch.
2. Give Astra Xhigh, with Daybreak explicitly disabled for that delegated architecture/code pass, a bounded prompt containing the verified native contract and the failing production-boundary fixture. Ask for the smallest supported design. Review its implementation yourself. Preserve the RED fixture; it must become GREEN because the actual production boundary is safe, not because the case was removed or stubbed.
3. Test cancellation and complete-B recovery through the real task hooks. A terminal veto may contain an unrecoverable error but does not count as recovered B. Preserve B's input revision, checkpoint validity, owners and in-flight work until the corrected target and required application/render tails finish.

**Exit:** changed-body selected regression GREEN, no forged completion or abandoned event, and a locally demonstrated recoverable B path or an explicit supported-window proof that the unsafe transition cannot occur. Then run the required full suite, native build/preflight and G0 certification before any live correction.

## 3. Choose and implement the smallest ownership strategy

After the policy and task boundary are settled, use Astra Xhigh with Daybreak disabled for code architecture and code edits; Root owns native verification, review, builds, tests, deployment, live evidence and cleanup.

1. Prefer logical rollback plus presentation reconciliation if consumer closure permits it. Separate only verified debris numeric motion from authoritative checkpoint storage, hashes and publication. Preserve live presentation owners safely while corrected logical events execute; remove old-history effects and create corrected-history effects at commit. Do not keep a logically dead owner active or suppress a required callback.
2. Keep exact reconstruction as fallback for any demonstrated combat/shared feedback; use deferred physical retirement only with a verified native removal/reinsertion and GPU ownership cycle. Retain existing exact PhysX/body/shape capture code and evidence until the replacement is demonstrated.
3. Close the enclosing trace Start before-effects lease and all affected birth/death routes, including factory-null, unretained birth and callback/member changes. Match selected lifecycle events to the shortest representative window. Preserve complete B through C settlement, target application/render work and GPU completion; timeouts and submission are not cancellation/completion.
4. Add failing-before/passing-after production-boundary regressions for each locally reproducible defect. Use `python tools/replay_test.py` selected layers during iteration, then current full suite/build/preflight at coherent checkpoints.

**Exit:** exact authoritative state plus coherent presentation can be captured, published, executed, recovered and retired without unowned references or hidden task effects.

## 4. Prove one complete seven-tick transaction

Run the shortest source-qualified candidate and independent modified control with identical setup/intro skip and authored inputs. At B624 retain complete B and its old revision; publish A617; execute exactly ticks 618–624 to C624; finish required application/render tails without advancing to 625; compare authoritative state, outcomes, callbacks, RNG, logical effects, physics interactions, poses and HUD. Commit only after C is settled and coherent; then observe at least 120 independently matching continuation ticks. Deliberately cancel one recoverable attempt and demonstrate 120 matching ticks from B. Keep raw bounded logs and source-qualified manifests.

**Exit:** real A617→C624 and B recovery, not a capture-only, constructor-only, private-ready or two-tick result. A first mismatch ends that experiment.

## 5. Qualify rolling correction in plan order

1. G4: 30 consecutive eligible depth-seven cycles, no silently skipped tick, stale revision, duplicate callback or visual corruption.
2. G5: 600 cycles plus 120 continuation ticks; report resimulated ticks separately from unique forward progress.
3. G6: deterministic changed-input arrivals, independent final-input controls, changed births/deaths and action outcomes, invalidated old-history checkpoints, then mixed unchanged/corrected cycles. Cover emerging G6 cases during short tests before the long campaign.
4. G7/G8: injected B cancellation and failures at each transaction phase, epoch/round transition, exit/re-entry and replay/scene replacement. Unrecoverable failures terminate safely and are not reported as successful B recovery.
5. G9/G10: normal-render coherence; native/GPU and deferred ownership accounting under the 1 GiB production ceiling; no growing backlog; full update time distribution for 600 unchanged and 600 changed cycles, including forward/render work; local input-correction adapter and supported configuration matrix.

Stop each experiment at its first failure, fix or instrument that exact failure, then rerun the relevant gate. Keep `docs/rollback-status.md` current with **implemented**, **locally tested**, **demonstrated live** and **unproven** stated separately. Use the deployment journal, verify mapped DLLs, restore prior files/configuration, terminate only owned test processes and leave existing Steam clients running.
