# Depth-seven local rollback plan

> Active continuation: [Rollback netcode local-readiness plan](rollback-netcode-local-readiness-plan-2026-09-22.md) governs implementation order and the consumer-proven state boundary. Read the [current status](rollback-status.md) for the latest source, test and live result; the [September 22 review](rollback-netcode-readiness-review-2026-09-22.md) is historical context. The original acceptance contract below is retained; the continuation preserves depth, anchors, eligibility, recovery, ownership, coherence and performance while requiring evidence before exact restoration of presentation state.

The text below preserves the original depth-seven implementation and acceptance contract. The replacement plan linked above governs current ordering and state classification. Current results and the next experiment belong in [rollback-status.md](rollback-status.md), not AGENTS.md or this plan. Archived notes are evidence, not instructions.

## Deliverable

Make **rolling rollback by seven native simulation ticks work every eligible tick** during active combat in one retained match session. Preserve and integrate the existing implementation. Use native replays as authored input sources and independent controls, and extend the existing test runner rather than creating another framework.

Correctness comes first: one representative seven-tick transaction, then repeated every-tick rollback, changed inputs, recovery and sustained performance. A helper, constructor, build, two-tick restore or single successful transaction does not complete this deliverable.

Networking, historical seeking, full-replay indexing, durable historical checkpoints, timeline controls, cross-round restoration and the historical strict-seek sentinel are outside this goal. Preserve their useful code and evidence. GekkoNet integration is a subsequent goal after local qualification. Exact shading, noise, render history and historical audio are not acceptance gates.

## Exact test semantics

Let S(T) mean the state after exactly T completed native simulation ticks, with the execution phase and pending native work explicitly represented. Do not assume a native tick equals an input sample, engine interval, application update or future network frame.

After seven ticks of warm-up within the current combat epoch, perform the following at every eligible T:

1. Retain complete **B = S(T)**, the pre-correction input revision and all ownership needed for undo. Select **A = S(T−7)** from the same session and combat epoch.
2. Publish A transactionally. Apply the chosen input revision through the real input-source API.
3. Execute exactly seven native simulation ticks to **C = S(T)**. Replay all required callbacks, input publications and pending work exactly once. The target must not silently advance to T+1 while completing application/render tails.
4. Finish required target application/render work, validate C, then commit and safely retire obsolete ownership. Cancellation or failure before commit retains the B recovery route.
5. Perform the ordinary forward update to S(T+1), retain the next checkpoint, and repeat. Required forward/render work belongs in the measured update cost.

The driver must report its actual T and T−7 each cycle, including missed cycles. Never silently skip a cycle because an owner expired, storage filled or completion was inconvenient. A rejected supported-window boundary is a failed test, not reduced coverage presented as success.

Retain at least eight logical boundaries for a depth-seven window, plus private B, operation state, scratch and deferred ownership as necessary. This does not mandate eight full copies: choose storage from measured requirements. A checkpoint is usable only when its state, input revision, epoch, bindings and owned resources are valid; capture success alone is insufficient.

For changed inputs, assign each correction a deterministic arrival tick, input-sample range and revision. Restore a boundary preceding the first affected simulation traversal, within the seven-tick window. Rebuild or invalidate later checkpoints derived from the old revision. Cancellation restores B's original history and checkpoint validity; commit adopts the corrected history. Inputs older than the supported window reject clearly.

## Non-negotiable ownership contract

Use the existing transaction owner and make these transitions observable:

**B retained → A published → corrected execution active → C settled → target application/render tails complete → irreversible commit → retirement complete.**

- Keep B recoverable through resimulation, CPU settlement, GPU drain and render completion. Do not release B at A publication or merely when a GPU command was submitted.
- Preserve exact logical particle birth/death, completion callbacks, scheduler membership, RNG, physics and animation. GC retention is not protection against explicit destruction.
- Compare detached native owner retention with reconstruction; choose the smallest design supported by native consumers. Deferred physical retirement must not keep logically dead owners active, suppress callbacks, revive PendingKill objects or alter future execution.
- Replacement owners require explicit typed bindings for manager slots, callbacks, scheduling, emitters, shared pools and render resources. Do not substitute pointers indiscriminately or assume an empty GPU constructor proves live rendering ownership.
- GPU timeout is not cancellation. Retain in-flight resources and references until completion; preserve existing deferred retirement and poisoned-operation guards.
- Failure must recover coherent B or terminate the retained session safely. Safe termination contains an unsupported failure; it does not count as successful B recovery in deliberate cancellation tests.
- Expected observations and hashes are comparison data only. They never supply simulation state or repair divergence.
- Keep coherent actors, weapons, effects, poses and HUD. Classify presentation-only state by its consumers and feedback before invalidating or omitting it.

## Ordered work packages

### 1. Close the current prerequisite and select a faster representative window

Inspect the moving checkout and latest retained report before editing. Finish or safely stop any active attempt and recover its deployment journal. Verify whether pending fixes are already applied; do not duplicate them.

Finish only the current native owner construction/retirement experiment needed to resolve the particle-lifetime design. Explicitly distinguish successful detached construction from registration, independent GPU ownership, restored state and continuation. Do not grow a general capture subsystem around this probe.

Search existing logs for an early active-combat window, preferably in round two, containing the relevant particle creation and destruction within seven ticks. If evidence is insufficient, run one bounded observation. Select by actual lifecycle/owner type, not a disappearing image. Skip intros consistently in candidate and native control. Retain tick 6415→6417 as the known GPU lifetime regression, but do not pay its startup cost for every routine retry.

Record the chosen start/end, round/epoch, particle type and logical events, pending task/interval work, input mapping, and expected time saved. If separate short windows are needed for CPU/GPU or pending-work coverage, state that explicitly. Do not move to an event-free window merely to get a pass.

Exit: one bounded executable experiment and a concrete ownership map. Unknowns must identify the consumed state or lifetime invariant and the smallest test that resolves them.

### 2. Assemble one real seven-tick rollback

Integrate only the owner construction/retention, typed rebinding and CPU/GPU lifecycle work required for the selected window. Preserve complete B and existing guards. Add failing-before/passing-after local regressions for reproducible defects, exercising production boundaries with controlled native dependencies.

Capture A, execute seven ticks to B through the relevant birth/death events, restore A, then independently reproduce the seven ticks and at least 120 subsequent ticks. Compare gameplay observations, inputs, callbacks, RNG-sensitive outcomes, physics and poses; component hashes alone are insufficient. Include actual pending native work. Verify exact tick landing and completed tails without hidden simulation advancement. Inspect representative actors/effects/poses/HUD.

Exit: one assembled seven-tick lifecycle transaction with independent continuation. Constructor-only, storage-only, same-process-only and protected-death abort results are not success.

### 3. Turn the transaction into rolling depth-seven execution

Add the bounded checkpoint/input window to the existing host and test driver. Exercise window warm-up, oldest-boundary selection, turnover, retained references and safe expiration. References held by B, an operation or pending GPU work outlive ring-slot eviction.

Run every-tick rollback for 30 consecutive eligible cycles first, then 600 consecutive cycles in active combat. Compare every regenerated traversal against the correctly aligned independent control and observe at least 120 native continuation ticks after the final rollback. Count resimulated ticks separately from unique forward progress. Do not count intentional warm-up or epoch reset as skipped eligible cycles.

Stop on the first mismatch or rejected cycle. Retain a bounded trace around it, fix the cause, then resume the relevant cases; do not repeat unrelated campaigns. Cover both CPU and GPU lifecycle paths and native repeat/multiple-tick input handling through explicit receipts or documented native-code justification where unreachable in this scope.

Exit: consecutive rolling cycles without drift, stale checkpoints, missed callbacks, unsafe retirement or visual corruption. A single successful rollback is not this gate.

### 4. Correct inputs independently

Use a deterministic correction schedule with arrivals inside the seven-tick window. Run an independent native control with the final corrected authored inputs and identical setup interventions. Compare candidate results only against the corresponding corrected history, with event and callback ordering retained.

Include corrections that change whether a particle birth or death occurs. Prove that old-history checkpoints are not reused after correction, and that unchanged-input cycles continue correctly after corrected cycles. Require 120 independently matching continuation ticks following the final correction. Keep simulation comparison and visual coherence results separate.

Exit: correct changed-input rolling execution, not merely unchanged-input replay under a renamed test.

### 5. Recover and reset safely

Inject cancellation before publication, during seven-tick resimulation and after GPU drain but before successful C/render settlement. Also exercise partial acquisition, failed publication/completion, repeated cleanup, invalidated bindings, capacity rejection and poisoned operations through local tests and the shortest native checks required.

For recoverable injected cases, recover complete B with its input revision/checkpoint validity, verify coherent presentation and 120 independently matching B continuation ticks. Returning a success code or terminating the process is not B recovery proof. For unrecoverable native failure, prove safe session termination and native reload; never resume partial state.

At a round transition, stop admitting old-epoch rollback, finish or recover pending work, drain retirement, discard the old window and establish a new baseline after seven ticks of warm-up. Test exit/re-entry and scene/replay replacement through native teardown/load. Do not restore across destroyed sessions.

Exit: the lifecycle matrix passes with no abandoned hooks, in-flight owners freed early, held actors or temporary deployment left behind. Leave unrelated Steam clients running.

### 6. Measure and qualify sustained cost

With diagnostic GPU readbacks disabled and the normal renderer enabled, measure both unchanged and changed-input rolling depth-seven execution. Use at least 600 consecutive cycles per configuration after warm-up; report sample count, hardware/configuration, median, p95, maximum and every update exceeding 16.7 ms.

Measure capture, B acquisition/preparation, publication, seven-tick resimulation, application/render completion, ordinary forward work and retirement separately where possible, plus end-to-end wall time. Account for overlapped work without double counting, and expose queued work that delays subsequent updates. Report deliberate holds separately. Measure observer overhead using compatible observation settings; do not subtract an assumed overhead to manufacture a pass.

The production gate is sustained full rollback updates within the 16.7 ms budget on the stated test machine, with no hidden growing backlog. Any observed overruns remain reported performance failures for that run. Resumed 60 TPS, simulation-only timing or a no-render diagnostic cannot qualify this gate.

Production ownership limit is 1 GiB. Account for peak simultaneous checkpoints, input history, complete B, operation state, scratch, native allocations, GPU allocations, in-flight resources and deferred retirement. Up to 2 GiB is permitted for bounded diagnosis, not production qualification. Identify unmeasured categories explicitly; increasing memory does not repair destroyed owners. Optimize the dominant measured costs, then rerun the affected correctness cases.

## Reporting and completion

Use `python tools/replay_test.py <stage>` and the existing checkout/build directory. New options or a focused stage may be added to that runner when needed; commands not implemented yet must be labelled proposed, never presented as runnable proof.

Each retained run records exact game/runtime/framework/observer/replay identities, reconstructible source archive, raw-log path/hash, setup interventions, correction schedule, coverage, first failure/check/phase/tick, B recovery status, memory/timing and cleanup. Preserve useful compatible controls. Simulation, observer validity, visual coherence, recovery and performance receive separate results; an aggregate pass requires all applicable gates.

The goal completes only when work packages 2–6 pass for the declared supported binary/replay/combat coverage, including every-tick rolling depth seven, changed lifecycle events and recovery. Record unsupported configurations honestly. Do not expand into networking or historical seeking to avoid an unresolved local gate.
