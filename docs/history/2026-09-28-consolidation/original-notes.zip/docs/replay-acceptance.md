# Rollback documentation has moved

The active scope and ordered acceptance plan are in [rollback-depth-seven-plan.md](rollback-depth-seven-plan.md).

Current results, remaining blockers and the next experiment are in [rollback-status.md](rollback-status.md). Keep status out of AGENTS.md.

The previous contents are preserved unchanged in [the pre-reset archive](history/depth-seven-reset-2026-09-14/replay-acceptance.md). Historical seeking and networking are deferred; old test gates in that archive are not current instructions.
